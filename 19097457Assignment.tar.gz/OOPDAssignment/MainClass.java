//****************************************************************
//Author: Prassana Kamalakannan
//Filename: MainClass.java
//DateModified: 29/10/2017
//****************************************************************

import java.util.*;

public class MainClass
{
    public static void main(String [] args)
    {
        DinosaurMenu.mainControlMenu();
    }//END MAIN
}
